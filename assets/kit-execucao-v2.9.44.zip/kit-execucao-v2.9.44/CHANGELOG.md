# Histórico de mudanças

## v2.9.44 — 2026-07-25

- Separa capacidade equivalente, orçamento e caixa.
- Introduz BOM com fonte, data, implantação, recorrência e horizonte.
- Calcula payback pela travessia do fluxo acumulado e inclui checagens de reconciliação.
- Adota quatro gates independentes.
- Impede escala automática em D+90.
- Explicita acesso clínico restrito e gestão agregada.
- Mantém P e L independentes, inclui efeito nulo, referência específica de Osaka e estresse aritmético de 4%.
- Decompõe o custo interno da etapa zero sem preencher taxas ou quantidades fictícias.
- Inclui contrato de análise, classificação melhoria/pesquisa, gate CEP/CONEP e registro de liberação dos instrumentos.
- Inclui nota técnica de proveniência das figuras assistidas por IA.
