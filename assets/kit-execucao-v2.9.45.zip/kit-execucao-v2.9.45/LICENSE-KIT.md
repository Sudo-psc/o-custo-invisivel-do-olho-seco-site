# Licença restrita do Kit de Execução

Copyright © 2026 Philipe Saraiva Cruz. Todos os direitos reservados.

O adquirente legítimo pode copiar e adaptar os arquivos identificados como Kit de Execução exclusivamente para uso interno da própria organização, mantendo atribuição ao autor, avisos metodológicos e salvaguardas. São vedadas a revenda e a redistribuição autônoma, gratuita ou onerosa, dos modelos ou de versões adaptadas. Instrumentos e conteúdos de terceiros permanecem sujeitos às respectivas licenças. Esta permissão não se estende ao restante do livro nem ao protocolo OVPP.

Esta licença específica prevalece para os arquivos identificados como Kit de
Execução, inclusive quando distribuídos em ZIP ou hospedados num repositório
cujo protocolo e website usem outra licença.
