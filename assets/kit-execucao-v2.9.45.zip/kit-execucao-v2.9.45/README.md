# Kit de Execução v2.9.45

Arquivos editáveis que acompanham **O Custo Invisível do Olho Seco**.

## Conteúdo

- `01_BOM_capacidade_e_caixa_v2.9.45.xlsx` — BOM, capacidade equivalente, caixa, quatro gates e relatório D+90.
- `02_Roteiro_CFO_v2.9.45.docx` — roteiro de reunião e objeções.
- `03_Relatorio_D90_v2.9.45.docx` — template de decisão da primeira fase.
- `04_Termo_privacidade_v2.9.45.docx` — modelo para revisão jurídica e de saúde ocupacional.
- `05_Apresentacao_executiva_v2.9.45.pptx` — apresentação executiva em oito slides.

## Contrato de uso

Capacidade equivalente não é perda contábil nem caixa. P e L são entradas independentes: teste efeito nulo; trate 1,26 p.p. somente como referência específica de Osaka; e 4% somente como estresse aritmético. A etapa zero decompõe horas de saúde ocupacional, RH, jurídico/DPO, TI, participantes, análise e governança. ROI só existe depois de benefício financeiro incremental atribuível observado e custo efetivo no mesmo horizonte. Payback usa fluxo acumulado, não divisão de totais. Adapte base legal, instrumentos, desenho e fluxo clínico ao contexto local. Antes da coleta, complete o contrato de análise e o registro de liberação de cada instrumento.

## Licença restrita do Kit de Execução

O adquirente legítimo pode copiar e adaptar os arquivos identificados como Kit de Execução exclusivamente para uso interno da própria organização, mantendo atribuição ao autor, avisos metodológicos e salvaguardas. São vedadas a revenda e a redistribuição autônoma, gratuita ou onerosa, dos modelos ou de versões adaptadas. Instrumentos e conteúdos de terceiros permanecem sujeitos às respectivas licenças. Esta permissão não se estende ao restante do livro nem ao protocolo OVPP.

Versão: `2.9.45`
Data: `2026-07-27`
